package com.sp.main;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApIwizAssignmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
