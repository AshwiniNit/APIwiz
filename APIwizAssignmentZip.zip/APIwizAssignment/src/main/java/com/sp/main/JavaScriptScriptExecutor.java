package com.sp.main;

import org.mozilla.javascript.Context;
import org.mozilla.javascript.Scriptable;

public class JavaScriptScriptExecutor {

    /**
     * Executes JavaScript scripts using Rhino.
     *
     * @param language - Should be "javascript" for JS execution.
     * @param script - Raw JavaScript code as a string.
     * @return - The result of the JavaScript execution.
     */
    public Object runScript(String language, String script) {
        if (language == null || script == null) {
            throw new IllegalArgumentException("Language and script cannot be null");
        }

        switch (language.toLowerCase()) {
            case "javascript":
                return executeJavaScript(script);
            default:
                throw new UnsupportedOperationException("Only JavaScript is supported in this version");
        }
    }

    /**
     * Executes JavaScript code using Rhino.
     *
     * @param script - The JavaScript script.
     * @return The result of the script execution.
     */
    private Object executeJavaScript(String script) {
        Context context = Context.enter();
        try {
            Scriptable scope = context.initStandardObjects();
            return context.evaluateString(scope, script, "<cmd>", 1, null);
        } finally {
            Context.exit();
        }
    }

    public static void main(String[] args) {
        JavaScriptScriptExecutor executor = new JavaScriptScriptExecutor();

        String jsCode = "var x = 10; var y = 5; x + y";  // Simple JavaScript
        Object result = executor.runScript("javascript", jsCode);

        System.out.println("JavaScript Execution Result: " + result);  // Output: 15
    }
}
