package com.sp.main;

import org.python.util.PythonInterpreter;

public class pythonScriptExecutor {

    /**
     * Executes Python scripts using Jython.
     *
     * @param language - Should be "python" for Python execution.
     * @param script - Raw Python code as a string.
     * @return - The result of the Python execution.
     */
    public Object runScript(String language, String script) {
        if (language == null || script == null) {
            throw new IllegalArgumentException("Language and script cannot be null");
        }

        switch (language.toLowerCase()) {
            case "python":
                return executePython(script);
            default:
                throw new UnsupportedOperationException("Only Python is supported in this version");
        }
    }

    /**
     * Executes Python script using Jython.
     *
     * @param script - The Python script.
     * @return The result of the script execution.
     */
    private Object executePython(String script) {
        PythonInterpreter interpreter = new PythonInterpreter();

        // Execute the Python script
        interpreter.exec(script);

        // Retrieve the result from the Python interpreter
        return interpreter.get("result");  // Assuming your Python script sets a variable named 'result'
    }

    public static void main(String[] args) {
        pythonScriptExecutor executor = new pythonScriptExecutor();

        String pythonScript = "result = 10 + 5"; // Simple Python script
        Object result = executor.runScript("python", pythonScript);

        System.out.println("Python Execution Result: " + result);  // Output: 15
    }
}
