package com.sp.main;

import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

class Node {
    int key;
    String name;
    List<Node> children = new ArrayList<>();  //List<Node>: यह list Node क्लास के ऑब्जेक्ट्स को ही रखेगी।
    AtomicInteger pendingParents = new AtomicInteger(0); //AtomicInteger एक Java class है,atomic (thread-safe) operations के साथ handle करने के लिए बनाई गई है।

    // Constructor to initialize node with key and name
    Node(int key, String name) {
        this.key = key;
        this.name = name;
    }

    // Adds a child node and increments the pendingParents counter of the child node
    void addChild(Node child) {
        children.add(child);
        child.pendingParents.incrementAndGet(); // Incrementing the pending parent count for the child node
    }
}

public class GraphExecutor {
    static Map<Integer, Node> nodeMap = new HashMap<>();
    static Set<Integer> executed = Collections.synchronizedSet(new HashSet<>());
    static List<String> executionOrder = Collections.synchronizedList(new ArrayList<>());

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Reading number of vertices in the graph
        int n = Integer.parseInt(sc.nextLine().trim());

        // Reading each node's details and adding it to the nodeMap
        for (int i = 0; i < n; i++) {
            String[] parts = sc.nextLine().split(":");
            int key = Integer.parseInt(parts[0]);
            String name = parts[1];
            nodeMap.put(key, new Node(key, name));
        }

        // Reading number of edges and creating the graph
        int m = Integer.parseInt(sc.nextLine().trim());

        // Creating edges and connecting parent-child nodes
        for (int i = 0; i < m; i++) {
            String[] edge = sc.nextLine().split(":");
            int from = Integer.parseInt(edge[0]);
            int to = Integer.parseInt(edge[1]);

            Node parent = nodeMap.get(from);
            Node child = nodeMap.get(to);
            parent.addChild(child);
        }

        // Starting the execution from the root node (key = 1)
        Node root = nodeMap.get(1);
        executeNode(root);

        // Wait for all threads to finish execution
        try {
            Thread.sleep(3000); // Adjust this sleep time to allow threads to finish
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Output the names of the nodes in the order they were executed
        for (String name : executionOrder) {
            System.out.println(name);
        }
        System.out.println("Total Nodes Executed: " + executionOrder.size());
    }

    // Method to execute a node, ensuring all its parent nodes are executed first
    static void executeNode(Node node) {
        new Thread(() -> {
            // Wait until all parents are executed (based on the pendingParents count)
            while (node.pendingParents.get() > 0) {
                try {
                    Thread.sleep(100); // Checking every 100ms if the node can be executed
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

            // Execute the node only if it has not been executed before
            synchronized (executed) {
                if (executed.contains(node.key)) return; // If the node is already executed, skip it
                executed.add(node.key);
            }

            System.out.println("Executing " + node.name); // Print the name of the node being executed
            executionOrder.add(node.name); // Add the node's name to the execution order list

            // Trigger execution of children in parallel threads
            for (Node child : node.children) {
                child.pendingParents.decrementAndGet(); // Decrement the pending parent count for the child
                executeNode(child); // Recursively execute the child node in parallel
            }

        }).start();
    }
}

