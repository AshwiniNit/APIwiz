package com.sp.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApIwizAssignmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApIwizAssignmentApplication.class, args);
	}

}
